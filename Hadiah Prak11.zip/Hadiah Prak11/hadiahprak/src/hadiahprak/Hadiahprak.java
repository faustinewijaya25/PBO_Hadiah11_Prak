/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hadiahprak;
import java.awt.*;
public class Hadiahprak extends Panel{
    /**
     * @param args the command line arguments
     */
    
    Hadiahprak() {
        setBackground(Color.GRAY);
    }
    public void paint(Graphics g) {
        Font f = new Font("Helvetica", Font.BOLD,20);
        FontMetrics fm = getFontMetrics(f);
        g.setFont(f);
        
        g.setColor(Color.BLUE);
        g.fillRect(50, 8, 390, 80);
        g.drawRect(50, 8, 390, 80);
        
        g.setColor(Color.BLUE);
        g.fillRect(50, 80, 500, 110);
        g.drawRect(50, 80, 500, 110);
        
        g.setColor(Color.red);
        g.drawOval(100, 150, 110, 110);
        g.fillOval(100, 150, 110, 110);
        
        g.setColor(Color.red);
        g.drawOval(350, 150, 110, 110);
        g.fillOval(350, 150, 110, 110);        
             
        
        String s = "Ini mobil dan nama saya Faustine";
        int xpos = (this.size().width - fm.stringWidth(s)) /2;
        int ypos = (this.size().height) /2;
        g.setColor(Color.black);
        g.setFont(f);
        g.drawString(s, xpos, ypos);
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Frame f = new Frame("Testing Graphics Panel");
        Hadiahprak gp = new Hadiahprak();
        f.add(gp);
        f.setSize(600,600);
        f.setVisible(true);
    }
    
}
